#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(int imId, double xPos, double yPos,  int dir, double size, int depth, StudentWorld* world)
    :GraphObject(imId, xPos, yPos, dir, size, depth){
        
    m_world = world;
    m_isAlive = true;
}
Actor::~Actor(){
    
}

void Actor::die(){
    m_isAlive = false;
}
bool Actor::isAlive(){
    return m_isAlive;
}
StudentWorld* Actor::getWorld(){
    return m_world;
}
///////////////////PROJECTILES///////////////////
Projectile::Projectile(int imId, double x, double y, int dir, StudentWorld* w):Actor(imId, x,y,dir,.5,1,w){
    //note, all projectiles have depth of 1, size of 0.5
}

Projectile::~Projectile(){
    
}
bool Projectile::hasCollided(){
    return false; //TODO
}
//------------CABBAGE-------------
Cabbage::Cabbage(double x, double y,StudentWorld* w):Projectile(IID_CABBAGE, x,y,0,w){
    
}
Cabbage::~Cabbage(){
    
}
void Cabbage::doSomething(){
    if(!isAlive())
        return;
    if(getX() >= VIEW_WIDTH){
        die();
        return;
    }
    if(hasCollided()){
        collide();
        return;
    }
    moveTo(getX()+8, getY()); //move 8 pixels to the right
    setDirection(getDirection()+20); //rotate 20 degrees to the right
    if(hasCollided()){
        collide();
        return;
    }
}

void Cabbage::collide(){
    //TODO: make collide functino
}

//-------------TURNIP---------------
Turnip::Turnip(double x, double y, StudentWorld* w):Projectile(IID_TURNIP, x,y,0,w){
    
}
Turnip::~Turnip(){
    
}
void Turnip::doSomething(){
    if(!isAlive())
        return;
    if(getX() > VIEW_WIDTH){
        die();
        return;
    }
    if(hasCollided()){
        //TODO: check if turnip has collided with player
        collide();
        return;
    }
    moveTo(getX()-6, getY());
    setDirection(getDirection()+20);
    if(hasCollided()){
        collide();
        return;
    }
    
}

void Turnip::collide(){
    //TODO: make collide function
}

//---------FLATULANCE TOPEDO--------
Torpedo::Torpedo(double x, double y, int dir, bool friendly, StudentWorld* w):Projectile(IID_TORPEDO, x,y, dir,w){
    m_friendlyToPlayer = friendly;
}
Torpedo::~Torpedo(){
    
}
void Torpedo::doSomething(){
    if(!isAlive())
        return;
    if(getX()<0 || getX()>= VIEW_WIDTH){
        die();
        return;
    }
    if(hasCollided()){
        collide();
        return;
    }
    if(m_friendlyToPlayer)
        moveTo(getX() + 8, getY());
    else
        moveTo(getX()-8, getY());
    if(hasCollided())
        collide();
    
}

void Torpedo::collide(){
    
}

/////////////////////PICK-UPS////////////////////////
PickUp::PickUp(int imId, double x, double y, StudentWorld* w):Actor(imId, x,y,0,0.5,1,w){
    
}
PickUp::~PickUp(){}

bool PickUp::hasCollided(){
    return false; //TODO:calculate collisions with player
}

void PickUp::doSomething(){
    if(!isAlive())
        return;
    if(getX()<0 || getY()<0){
        die();
        return;
    }
    if(hasCollided()){
        collide();
        return;
    }
    moveTo(getX()-0.75, getY()-0.75);
    if(hasCollided())
        collide();
}

//----------------ONE-UP------------------
OneUp::OneUp(double x, double y, StudentWorld* w):PickUp(IID_LIFE_GOODIE, x,y,w){
}
OneUp::~OneUp(){
    
}
void OneUp::collide(){
    
}

//-----------------REPAIR-GOODIE------------
Repair::Repair(double x, double y, StudentWorld* w):PickUp(IID_REPAIR_GOODIE, x,y,w){
    
}
Repair::~Repair(){};
void Repair::collide(){
    
}

//////////////////////////ALIENS/////////////////////////////
//-------------------



////////////////////////NACHENBLASTER//////////////////////////
NachenBlaster::NachenBlaster(StudentWorld* w):Actor(IID_NACHENBLASTER, 0, 128, 0, 1.0, 0,w){
    m_health = 50;
    m_nCabbage = 30;
}
NachenBlaster::~NachenBlaster(){
    
}
void NachenBlaster::doSomething(){
    if(!isAlive())
        return;
    int ch;
    if(getWorld()->getKey(ch)){
        switch (ch) {
            case KEY_PRESS_LEFT:
                if(getX()>=6)
                    moveTo(getX()-6, getY());
                break;
            case KEY_PRESS_RIGHT:
                if(getX()<VIEW_WIDTH-6)
                    moveTo(getX()+6, getY());
                break;
            case KEY_PRESS_UP:
                if(getY()<VIEW_HEIGHT-6)
                    moveTo(getX(), getY()+6);
                break;
            case KEY_PRESS_DOWN:
                if(getY()>=6)
                moveTo(getX(), getY()-6);
                break;
                
            default:
                break;
        }
    }
}



/////////////////////BACKGROUND OBJECTS/////////////////////////
//----------------------STARS------------------------
Star::Star(double x, double y, StudentWorld* w):Actor(IID_STAR, x,y, 0, 0.01*randInt(5, 50) , 3,w){
    
}
Star::~Star(){
    
}
void Star::doSomething(){
    if(getX() <= -1)
        die();
    else
        moveTo(getX()-1, getY());
}

//--------------------EXPLOSIONS------------------------
Explosion::Explosion(double x, double y, StudentWorld* w):Actor(IID_EXPLOSION, x,y, 0, 1, 0,w){
    
}
Explosion::~Explosion(){
    
}
void Explosion::doSomething(){
    setSize(getSize()*1.5);
    if(getSize()>5.0625)
        die();
}







