#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <list>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetDir)
: GameWorld(assetDir)
{
}

StudentWorld::~StudentWorld(){
    cleanUp();
}

int StudentWorld::init()
{
    m_player = new NachenBlaster(this);
    for(int i=0; i<30; i++){
        m_objects.push_front(new Star(randInt(0, VIEW_WIDTH-1), randInt(0, VIEW_HEIGHT-1), this));
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    m_player->doSomething();
    
    list<Actor*>::iterator i = m_objects.begin();
    
    while(i!=m_objects.end()){
        (*i)->doSomething();
        i++;
    }
    
    i=m_objects.begin();
    list<Actor*>::iterator toDestroy = i;
    while(i!=m_objects.end()){
        if(!(*i)->isAlive()){
            toDestroy =i;
            i--;
            delete (*toDestroy);
            m_objects.erase(toDestroy);
        }
        i++;
    }
    
    //instantiate a new star, with a 1/15 chance
    if(randInt(0, 14) == 0){
        m_objects.push_front(new Star(VIEW_WIDTH-1, randInt(0, VIEW_HEIGHT-1), this));
    }
    
    decLives();
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete  m_player;
    list<Actor*>::iterator i;
    i=m_objects.begin();
    while(i!= m_objects.end()){
        delete (*i);
        i++;
    }
}
