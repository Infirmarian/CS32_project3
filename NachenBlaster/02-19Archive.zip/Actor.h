#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;


class Actor: public GraphObject{
public:
    Actor(int imId, double xPos, double yPos,  int dir, double size, int depth, StudentWorld* world);
    virtual ~Actor();
    void die();
    bool isAlive();
    virtual void doSomething()=0;
    StudentWorld* getWorld();
private:
    bool m_isAlive;
    StudentWorld* m_world;
    
};

class Projectile: public Actor{
public:
    Projectile(int imId, double x, double y, int dir, StudentWorld* w);
    virtual ~Projectile();
    bool hasCollided();
    virtual void doSomething() =0;
    virtual void collide()=0;
    
};

///////////////////PROJECTILES///////////////////////////
//-------------------CABBAGE-----------------------
class Cabbage: public Projectile{
public:
    Cabbage(double x, double y, StudentWorld* w);
    virtual ~Cabbage();
    virtual void doSomething();
    virtual void collide();
};

//------------------TURNIP----------------------
class Turnip: public Projectile{
public:
    Turnip(double x, double y, StudentWorld* w);
    virtual ~Turnip();
    virtual void doSomething();
    virtual void collide();
};

//------------FLATULANCE TORPEDO--------------
class Torpedo: public Projectile{
public:
    Torpedo(double x, double y, int dir, bool friendly, StudentWorld* w);
    virtual ~Torpedo();
    virtual void doSomething();
    virtual void collide();
private:
    bool m_friendlyToPlayer;
};
///////////////////////PICK-UPS/////////////////////////
class PickUp:public Actor{
public:
    PickUp(int imId, double x, double y, StudentWorld* w);
    virtual ~PickUp();
    bool hasCollided();
    virtual void doSomething();
    virtual void collide()=0;
};
//---------------------EXTRA-LIFE--------------------
class OneUp:public PickUp{
public:
    OneUp(double x, double y, StudentWorld* w);
    virtual ~OneUp();
    virtual void collide();
};

//-----------------REPAIR-GOODIE--------------------
class Repair:public PickUp{
public:
    Repair(double x, double y, StudentWorld* w);
    virtual ~Repair();
    virtual void collide();
    
};
//-----------------TORPEDO-GOODIE-------------------

//NachenBlaster class (main player character)
class NachenBlaster: public Actor{
public:
    NachenBlaster(StudentWorld* w);
    virtual ~NachenBlaster();
    
    virtual void doSomething();
private:
    int m_health;
    int m_nCabbage;
};


//Star class
class Star: public Actor{
public:
    Star(double x, double y, StudentWorld* w);
    virtual ~Star();
    virtual void doSomething();
};

//Explosion class
class Explosion: public Actor{
public:
    Explosion(double x, double y, StudentWorld* w);
    virtual ~Explosion();
    virtual void doSomething();
};




#endif // ACTOR_H_
